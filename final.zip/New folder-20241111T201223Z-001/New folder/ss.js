// Simple interactive function for alert (Mock symptom checker)
function checkSymptom() {
    const symptom = prompt("Enter your symptom:");
    alert(`Based on "${symptom}", we recommend a consultation.`);
}
